'use client';

import TopUsers from "@/components/shared/topusers";
import Link from "next/link";
import Image from "next/image";
import {ChevronRight} from "lucide-react";
import useTelegramStore from "@/store/useUserTelegram";

export default function Home() {
    const {telegramUser} = useTelegramStore()

    return (
        <div className='h-full'>
            <div className="flex flex-col gap-2 items-center">
                <TopUsers/>
                <Link
                    href="/pacman"
                    className="text-xs bg-yellow-400/25 text-lg border-yellow-400 border  bottom-20 p-2 rounded-3xl  w-10/12 text-center flex justify-between">
                    <div className="flex gap-2 items-center ">
                        <Image
                            src="/pacman.svg"
                            alt="heart"
                            width={48}
                            height={48}
                            className="w-[16px] h-[16px]"
                        />
                        PACMAN
                    </div>

                    <div className="flex items-center uppercase">
                        <p>{telegramUser.lang == 'ru' ? 'играть' : 'play'}</p>
                        <ChevronRight/>
                    </div>
                </Link>
				
				<Link
                    href="/donkey"
                    className="text-xs bg-yellow-400/25 text-lg border-yellow-400 border  bottom-20 p-2 rounded-3xl  w-10/12 text-center flex justify-between">
                    <div className="flex gap-2 items-center ">
                        <Image
                            src="/dokey.png"
                            alt="heart"
                            width={48}
                            height={48}
                            className="w-[16px] h-[16px]"
                        />
                        DONKEY
                    </div>

                    <div className="flex items-center uppercase">
                        <p>{telegramUser.lang == 'ru' ? 'играть' : 'play'}</p>
                        <ChevronRight/>
                    </div>
                </Link>

                <Link
                    href="https://t.me/arcade_meme/8"
                    className="text-sm bg-violet-400/25 text-lg border-violet-400 border mx-auto p-2 rounded-3xl w-10/12 text-center flex justify-between">
                    <div className="flex gap-2 items-center uppercase">
                        <Image
                            src="/telegram.svg"
                            alt="heart"
                            width={48}
                            height={48}
                            className="w-[16px] h-[16px]"
                        />
                        {telegramUser.lang == 'ru' ? 'следить за новостями' : 'Follow the news'}
                    </div>

                    <div className="flex items-center ">
                        <ChevronRight/>
                    </div>
                </Link>
                <div className="w-10/12 flex gap-2">
                    <Link
                        href="https://t.me/blum/app?startapp=memepadjetton_BLINKY_ZSLXl-ref_HgypygN3Sw"
                        className="text-sm bg-violet-400/25 text-lg border-red-600 border mx-auto p-2 rounded-3xl w-6/12 text-center flex justify-between">
                        <div className="flex gap-2 items-center uppercase">
                            <Image
                                src="/blum.jfif"
                                alt="heart"
                                width={48}
                                height={48}
                                className="w-[16px] h-[16px] rounded-full"
                            />
                            $BLINKY
                        </div>

                        <div className="flex items-center ">
                            <ChevronRight/>
                        </div>
                    </Link>
                    <Link
                        href="https://t.me/blum/app?startapp=memepadjetton_PINKY_PynLL-ref_HgypygN3Sw"
                        className="text-sm bg-violet-400/25 text-lg border-pink-600 border mx-auto p-2 rounded-3xl w-6/12 text-center flex justify-between">
                        <div className="flex gap-2 items-center uppercase">
                            <Image
                                src="/blum.jfif"
                                alt="heart"
                                width={48}
                                height={48}
                                className="w-[16px] h-[16px] rounded-full"
                            />
                            $PINKY
                        </div>

                        <div className="flex items-center ">
                            <ChevronRight/>
                        </div>
                    </Link>
                </div>
                <div className="w-10/12">
                    <Link
                        href="https://t.me/blum/app?startapp=memepadjetton_INKY_vYTrX-ref_HgypygN3Sw"
                        className="text-sm bg-violet-400/25 text-lg border-blue-600 border mx-auto p-2 rounded-3xl text-center flex justify-between">
                        <div className="flex gap-2 items-center uppercase">
                            <Image
                                src="/blum.jfif"
                                alt="heart"
                                width={48}
                                height={48}
                                className="w-[16px] h-[16px] rounded-full"
                            />
                            $INKY
                        </div>

                        <div className="flex items-center ">
                            <ChevronRight/>
                        </div>
                    </Link>
                </div>
            </div>


        </div>
    );
}