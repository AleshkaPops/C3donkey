'use client'

import { backButton } from '@telegram-apps/sdk-react';
import { useEffect } from "react";

export default function Pacman() {
	useEffect(() => {
		if (backButton.onClick.isAvailable()) {
			backButton.mount();
			backButton.show()
		}

		if (backButton.onClick.isAvailable()) {
			const listener = () => {
				window.location.href = "/";
				backButton.hide();
				backButton.isVisible();
			}

			backButton.onClick(listener);
		}
	}, [])

	return (
		<div className="flex flex-col gap-4 items-center overflow-hidden">
			<iframe
				src="/pacman-js-master/index.html"
				className=" w-screen h-screen fixed top-0 left-0 overflow-hidden"></iframe>
		</div>
	);
}
