'use client'

import { Open_Sans, Unbounded } from "next/font/google";
import "./globals.css";
import Ellipe from "@/components/ui/ellipse";
import { init, retrieveLaunchParams } from '@telegram-apps/sdk-react';
import { useEffect, useState } from "react";
import useUserStore from "@/store/useUserStore";
import useTelegramStore from "@/store/useUserTelegram"
import apiClient from "@/axios";
import { swipeBehavior } from '@telegram-apps/sdk-react';
import Header from "@/components/shared/header";

const unbounded = Unbounded({
	variable: "--font-unbounded-sans",
	subsets: ["latin"],
});

const openSans = Open_Sans({
	variable: "--font-open-sans",
	subsets: ["latin"],
});

export default function RootLayout({
	children,
}: Readonly<{
	children: React.ReactNode;
}>) {
	const [status, setStatus] = useState(false)
	const {setUser, setBearerToken} = useUserStore()
	const {setTelegramUser} = useTelegramStore()

	useEffect(() => {
		init();

		const initUser =  () => {
			try {
				const userTelegramData = retrieveLaunchParams().tgWebAppData?.user

				setTelegramUser({
					id: userTelegramData?.id,
					first_name: userTelegramData?.first_name,
					last_name: userTelegramData?.last_name,
					username: userTelegramData?.username,
					is_premium: userTelegramData?.is_premium,
					photo_url: userTelegramData?.photo_url,
					lang: userTelegramData?.language_code
				})

				apiClient.post('/v1/user/auth', {
					userId: userTelegramData?.id,
					fullName: userTelegramData?.first_name ?? '' + userTelegramData?.last_name ?? '',
					avatar: userTelegramData?.photo_url ?? '',
					username: userTelegramData?.username,
				}).then(userResposne => {
					localStorage.setItem('bearer_token', userResposne.data.token)
					localStorage.setItem('highScore', userResposne.data.user.coin)

					setBearerToken(userResposne.data.token)
					setUser(userResposne.data.user)


					setStatus(true)
				});

				const script = document.createElement('script');

				script.type = 'text/javascript';
				script.innerHTML = `
					(function(m,e,t,r,i,k,a){
						m[i]=m[i] || function(){(m[i].a=m[i].a||[]).push(arguments)};
						m[i].l=1*new Date();
						for (var j = 0; j < document.scripts.length; j++) {
						if (document.scripts[j].src === r) { return; }
						}
						k=e.createElement(t),a=e.getElementsByTagName(t)[0];
						k.async=1;
						k.src=r;
						a.parentNode.insertBefore(k,a)
					})(window, document, "script", "https://mc.yandex.ru/metrika/tag.js", "ym");
				
					ym(100207501, "init", {
						clickmap:true,
						trackLinks:true,
						accurateTrackBounce:true
					});
				`;

				document.head.appendChild(script);
			
				const noscript = document.createElement('noscript');
				noscript.innerHTML = `
				<div>
					<img src="https://mc.yandex.ru/watch/100207501" style="position:absolute; left:-9999px;" alt="" />
				</div>
				`;
				document.body.appendChild(noscript);
			
				return () => {
					document.head.removeChild(script);
					document.body.removeChild(noscript);
				};
			} catch (error) {
				console.log(error)
				setStatus(false)
			}
		}

		initUser()
	}, [setTelegramUser, setBearerToken, setUser, setStatus])

	useEffect(() => {
		if (swipeBehavior.mount.isAvailable()) {
			swipeBehavior.mount();
			swipeBehavior.isMounted(); // true
			swipeBehavior.disableVertical();
			swipeBehavior.isVerticalEnabled(); // false
		}
	}, [])

	if (!status) {
		return (
			<html lang="en">
			<body
				className={`${unbounded.variable} ${openSans.variable} font-[unbounded] antialiased overflow-hidden py-24 bg-black max-w-2xl mx-auto h-screen px-4`}>
				<p>wait</p>
			</body>
		</html>
		);
	}

	return (
		<html lang="en">
			<body
				className={`${unbounded.variable} ${openSans.variable} font-[unbounded] antialiased overflow-hidden pt-24 bg-black max-w-2xl mx-auto h-screen px-4`}>

				<div className="z-40 relative h-full">
					<Header />
					{children}
				</div>

				<Ellipe />
			</body>
		</html>
	);
}
