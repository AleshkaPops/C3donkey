"use client";

import apiClient from "@/axios";
import { ChartNoAxesColumn } from "lucide-react";
import Image from "next/image";
import { useEffect } from "react";
import useUserStore from "@/store/useUserStore";
import { backButton } from "@telegram-apps/sdk-react";
import useTelegramStore from "@/store/useUserTelegram";

export default function Leaders() {
	// const [users, setUsers] = useState<User[]>([]);
	const { user, userTop2, setUserTop2 } = useUserStore();
	const {telegramUser} = useTelegramStore()

	useEffect(() => {
		apiClient
			.post("/v1/user/leaders")
			.then((res) => {
				setUserTop2(res.data.data);
			})
			.catch((error) => {
				console.error("Ошибка при загрузке топ пользователей:", error);
			});
	}, [setUserTop2]);

	useEffect(() => {
		if (backButton.onClick.isAvailable()) {
			backButton.mount();
			backButton.show();
		}

		if (backButton.onClick.isAvailable()) {
			const listener = () => {
				window.location.href = "/";
				backButton.hide();
				backButton.isVisible();
			};

			backButton.onClick(listener);
		}
	}, []);

	return (
		<div className="flex flex-col gap-4 items-center">
			<div className="p-3 font-[unbounded] bg-white/10 h-[70vh] rounded-2xl w-full flex flex-col gap-1">
				<div className="w-full flex justify-between items-center">
					<h2 className="text-sm">{telegramUser.lang == 'ru' ? 'Топ пользователей' : 'Top Users'}	</h2>
					<ChartNoAxesColumn size={16} />
				</div>
				<ul className="flex flex-col gap-2 items-center h-[70vh] overflow-y-auto rounded-2xl scrollbar-hide">
					<hr className="opacity-10 w-11/12" />

					{userTop2.map((userTop, index) => (
						<li
							key={userTop.id}
							className={`flex w-full justify-between ${
								user.id == userTop.id
									? "border border-[#0059FF] bg-[#0059FF]/15 rounded-3xl p-2"
									: ""
							}`}>
							<div className={`flex gap-2 items-center`}>
								<Image
									src={userTop.avatar || "/avatar.jpeg"}
									alt="crinje"
									width={48}
									height={48}
									className="w-[48px] h-[48px] rounded-2xl"
								/>
								<div className="flex flex-col">
									<h2 className="text-sm">{userTop.full_name}</h2>
									<p className="text-xs opacity-40">@{userTop.username}</p>
								</div>
							</div>
							<div className="flex items-end gap-1 justify-center flex-col">
								{userTop.id && (
									<span
										className={`px-2 text-xs py-1 rounded-full flex gap-2 w-fit
											${
												index == 0
													? "text-[#FFCC00] bg-[#FFCC00]/20"
													: index == 1
													? "text-[#E2E2E2] bg-[#E2E2E2]/20"
													: "text-[#C95E00] bg-[#C95E00]/20"
											}
										`}>
										{index + 1}
									</span>
								)}
								<span className="px-2 text-xs py-1 rounded-full bg-white/20 flex gap-2 w-fit">
									{userTop.coin}
									<Image src="/coin.svg" alt="coin" width={16} height={16} />
								</span>
							</div>
						</li>
					))}
				</ul>
			</div>
		</div>
	);
}
